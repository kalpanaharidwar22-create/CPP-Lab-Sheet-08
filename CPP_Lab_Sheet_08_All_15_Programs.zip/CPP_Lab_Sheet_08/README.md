# C++ Lab Sheet-08
BCA I Semester — Functions and OOPs Concepts in C++

This repository contains 15 separate C++ programs from Lab Sheet-08.

## Programs
1. Prime number
2. Fibonacci series
3. Bubble sort
4. Copy a string
5. Count words in a string
6. Binary search (enter elements in ascending order)
7. Sum of two matrices
8. Sum of main diagonal elements
9. Swap using call by reference
10. Student class
11. Car class with multiple objects
12. Encapsulation using BankAccount
13. Single inheritance
14. Function overloading
15. Abstraction using an abstract Shape class

## How to run
Compile one file at a time with a C++ compiler, for example:
`g++ 01_Prime.cpp -o prime`
Then run the generated program.

Each `.cpp` file has its own `main()` function, so compile and run files separately.
